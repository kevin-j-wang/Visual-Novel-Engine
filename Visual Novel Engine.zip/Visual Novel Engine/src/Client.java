
import java.util.ArrayList;
import java.util.HashMap;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.input.MouseButton;

public class Client extends Application {
	private ImageView playButton;
	private ImageView quitButton;
	private ImageView backGround;
	private Scene scene;
	private Group group;
	private String title;
	private String author;
	private String date;
	public Canvas canvas;
	public static GraphicsContext gc;
	public static Font font;
	public static boolean drawText = true;
	public Menu menu;
	private boolean menuOpen = false;
	private static int panelNum = 1;
	public static boolean endGame = false;
	public static boolean inProgress = false;
	public static boolean visible = true;
	private ArrayList<Panel> panelSequence = new ArrayList<>();
	private HashMap<String, Character> characters = new HashMap<>();
	static int charNum = 0;
	/**
	 * Effectively the main method.
	 */
	public void start(Stage clientStage) throws Exception {
		// Declare all images here, initialize them shortly after.
		Image background = null, play = null, quit = null, quitHover = null, quit2 = null, load = null,
				loadHover = null, graphic = null, graphicHover = null, save = null, saveHover = null;
		background = new Image("file:data/assets/menu/background.png");
		play = new Image("file:data/assets/menu/playButton.png");
		quit = new Image("file:data/assets/menu/quitButton.png");
		quitHover = new Image("file:data/assets/menu/menuQuitButtonHover.png");
		quit2 = new Image("file:data/assets/menu/menuQuitButton.png");
		load = new Image("file:data/assets/menu/loadButton.png");
		loadHover = new Image("file:data/assets/menu/loadButtonHover.png");
		graphic = new Image("file:data/assets/menu/graphicButton.png");
		graphicHover = new Image("file:data/assets/menu/graphicButtonHover.png");
		save = new Image("file:data/assets/menu/saveButton.png");
		saveHover = new Image("file:data/assets/menu/saveButtonHover.png");
		// Make sure to make all buttons preserve ratio to prevent wacky
		// resizing,
		// unless of course you want your image to be resized uncontrollably.
		playButton = new ImageView(play);
		playButton.setPreserveRatio(true);
		quitButton = new ImageView(quit);
		quitButton.setPreserveRatio(true);
		backGround = new ImageView(background);
		backGround.setPreserveRatio(true);
		group = new Group();
		scene = new Scene(group, 960, 540);
		// Set the width and height of all panels to be the same size as the
		// window,
		// they are static doubles.
		// Whenever the size of the displayed area is needed, use the following
		// fields.
		Panel.panelWidth = scene.getWidth();
		Panel.panelHeight = scene.getHeight();
		// Make a menu that pops up upon right clicking anywhere.
		menu = new Menu(save, saveHover, load, loadHover, quit2, quitHover, graphic, graphicHover);
		clientStage.setScene(scene);
		// Removes the top bar so that the height and width are actually
		// accurate, and
		// also makes it look CLEAN
		clientStage.initStyle(StageStyle.TRANSPARENT);
		clientStage.show();
		clientStage.setResizable(false);
		canvas = new Canvas(scene.getWidth(), scene.getHeight());
		gc = canvas.getGraphicsContext2D();
		font = new Font("Calibri", 40);
		gc.setFont(font);
		group.getChildren().add(backGround);
		group.getChildren().add(canvas);
		group.getChildren().add(quitButton);
		group.getChildren().add(playButton);
		menu.initMenu(group);
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				if (mouseEvent.getButton() == MouseButton.SECONDARY) {
					if (menuOpen) {
						menuOpen = false;
						menu.closeMenu(group);
					} else {
						menuOpen = true;
						menu.openMenu(group);
					}
				}
			}
		});
		refreshLayout();
		playButton.setOnMouseClicked(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				hideMainMenu();
				clientStage.show();
				refreshLayout();
				playGame();
			}
		});
		quitButton.setOnMouseClicked(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				System.exit(0);
			}
		});
	}

	public void initialize() {
		launch();
	}

	// Include all Buttons added here.
	// Call this method whenever window size is changed.
	public void refreshLayout() {
		playButton.setFitWidth(scene.getWidth() / 8);
		quitButton.setFitWidth(scene.getWidth() / 8);
		backGround.setFitWidth(scene.getWidth() + 10);
		playButton.setLayoutY(scene.getHeight() / 7 * 4 - playButton.getFitHeight() / 2);
		playButton.setLayoutX(scene.getWidth() / 8 - playButton.getFitWidth() / 2);
		quitButton.setLayoutY(scene.getHeight() / 7 * 5 - quitButton.getFitHeight() / 3);
		quitButton.setLayoutX(scene.getWidth() / 8 - quitButton.getFitWidth() / 2);
	}
	/**
	 * removes the ImageViews from being seen, important for playing the game.
	 */
	public void hideMainMenu() {
		playButton.setVisible(false);
		quitButton.setVisible(false);
	}
	/**
	 * shows the ImageViews if they are hidden.
	 */
	public void showMainMenu() {
		playButton.setVisible(true);
		quitButton.setVisible(true);
	}

	// Returns the index of the current panel being viewed. Used for saving the
	// game.
	public static int getPanelNum() {
		return panelNum;
	}

	/**
	 * Sets the index of the panel to be viewed to the single parameter. Used
	 * for loading the game.
	 * 
	 * @param num
	 *            The number to set the index to.
	 */
	public static void setPanelNum(int num) {
		panelNum = num;
	}

	/**
	 * Method that processes all data from given files then takes in input in
	 * the form of mouseclicks to advance the game.
	 */
	public void playGame() {
		DataReader reader = new DataReader("game");
		title = reader.read();
		author = reader.read();
		date = reader.read();
		charNum = Integer.parseInt(reader.read());
		for (int i = 0; i < charNum; i++) {
			Character tempChar = new Character(reader.read());
			characters.put(tempChar.getName(), tempChar);
		}
		//By default, all games have a character called "none", which is just a transparent image, used for when there is no character in the scene.
		characters.put("none", new Character("none"));
		// Adds nothing to the 0th panel, just to make the entire ArrayList
		// 1-indexed. This is helpful for saving and loading the game.
		panelSequence.add(null);
		String line;
		boolean end = false;
		// Reads in lines from the file given until the end of file, or until
		// the line is labeled "#End", then makes an ArrayList with information
		// compiled into a format that can easily be converted into a drawable
		// panel in the next section.
		// This takes some time, and the user should not input anything until the buttons disappear.
		while ((line = reader.read()) != null && !end) {
			ArrayList<String> panelInfo = new ArrayList<>();
			while (true) {
				panelInfo.add(line);
				if (line.equals("#Next") || line.equals("#End")) {
					if (line.equals("#End")) {
						end = true;
					}
					break;
				}
				line = reader.read();
			}
			Panel tempPanel = null;
			// Creates a different type of panel with its corresponding
			// parameters based off of the specification given in the text file.
			// Unfortunately, only 1 kind of panel will be implemented at the
			// time of this assignment being due.
			// 0 is the type of panel, 1 preanimation, 2 is the background, 3 is
			// the character, 4 is the subcharacter (emotional variants), 5 is
			// the text in the panel, and 6 is the postanimation.
			if (panelInfo.get(0).equals("#Default") || panelInfo.get(0).equals("#Common")) {
				/**
				 * The parameters are explained as above.
				 */
				tempPanel = new CommonPanel(new Image("file:data/assets/backgrounds/" + panelInfo.get(2)),
						characters.get(panelInfo.get(3)).get(panelInfo.get(4)), panelInfo.get(5), panelInfo.get(1),
						panelInfo.get(6));
			}
			panelSequence.add(tempPanel);
		}
		// Adds a special kind of panel called the ending panel. This panel is a
		// simple black screen with "THE END" printed in the center
		panelSequence.add(new EndPanel(new Image("file:data/assets/menu/background.png"),
				new Image("file:data/assets/menu/background.png")));
		scene.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				// If the panel is marked with #End, exit the game upon further
				// input.
				if (endGame) {
					System.exit(0);
				}
				// Advances a panel upon left-clicking. Draws text or doesn't
				// depending on if the Show Graphics button has been pressed.
				if (mouseEvent.getButton() == MouseButton.PRIMARY && menuOpen == false && !inProgress) {
					if (drawText) {
						panelSequence.get(panelNum).draw(gc);
					} else {
						panelSequence.get(panelNum).drawNoText(gc);
					}
					panelNum++;
				}
			}
		});
	}
}
