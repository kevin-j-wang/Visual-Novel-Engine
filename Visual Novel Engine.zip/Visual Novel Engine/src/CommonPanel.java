import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class CommonPanel extends Panel {
	private Text panelText;
	public double textBoxWidth = panelWidth - bezelSize * 2;
	/**
	 * Sets the background image, character image, the animations to be run before and after drawing the panel, and the text that will be written on the panel.
	 * @param backgroundImage A rectangular image that depicts a scene
	 * @param characterImage A transparent image that contains a character
	 * @param panelContents A string that contains dialogue pertaining to the scene
	 * @param preEffect The type of animation to be shown before the scene
	 * @param postEffect The type of animation to be shown after the scene
	 */
	public CommonPanel(Image backgroundImage, Image characterImage, String panelContents, String preEffect, String postEffect) {
		super(backgroundImage, characterImage);
		this.panelText = new Text(panelContents);
		this.preEffectType = preEffect;
		this.postEffectType = postEffect;
	}
	// Draws the everything a normal panel would have, text, a background, a
	// character, etc.
	@Override
	public void draw(GraphicsContext gc) {
		Timeline timeline = new Timeline();
		//The keyframe doesn't have anything in it because every action is within the handle method within the FrameProcessor class.
		KeyFrame frame = new KeyFrame(Duration.seconds(0.024), new FrameProcessor(gc, panelText.getText(), background, character, preEffectType, postEffectType, textBoxWidth, timeline){});
		timeline.getKeyFrames().add(frame);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}
	
	public void drawNoText(GraphicsContext gc) {
		Timeline timeline = new Timeline();
		//The keyframe doesn't have anything in it because every action is within the handle method within the FrameProcessor class.
		KeyFrame frame = new KeyFrame(Duration.seconds(0.024), new FrameProcessor(gc, false, background, character, preEffectType, postEffectType, timeline){});
		timeline.getKeyFrames().add(frame);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}
}
