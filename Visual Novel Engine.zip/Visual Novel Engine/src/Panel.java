import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public abstract class Panel {
	protected Image background;
	protected Image character;
	protected String preEffectType;
	protected String postEffectType;
	public static double panelWidth;
	public static double panelHeight;
	public static double bezelSize = 40;
	public static Color textBoxColor = new Color(0,0,0,0.8);
	public Panel(Image backgroundImage, Image characterImage) {
		background = backgroundImage;
		character = characterImage;
	}
	/**
	 * abstract methods that all pass a GraphicsContext as a parameter, as that is what things are drawn to.
	 * @param gc	The GraphicsContext that everything will be drawn to.
	 */
	public abstract void draw(GraphicsContext gc);
	//Does not draw the text, so the player can admire the scenery.
	public abstract void drawNoText(GraphicsContext gc);
	//Clears the screen
	public void clear(GraphicsContext gc) {
		gc.clearRect(0, 0, panelWidth, panelHeight);
	}
	
	public void fadeToBlack(GraphicsContext gc) {
		Timeline timeline = new Timeline();
		//The keyframe doesn't have anything in it because every action is within the handle method within the FrameProcessor class.
		KeyFrame frame = new KeyFrame(Duration.seconds(0.024), new FrameProcessor(gc, true, background, character, preEffectType, postEffectType, timeline){});
		timeline.getKeyFrames().add(frame);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}
	
}
