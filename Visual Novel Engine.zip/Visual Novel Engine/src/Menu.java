import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;

public class Menu {
	private ImageView saveButton = new ImageView();
	private ImageView loadButton = new ImageView();
	private ImageView quitButton = new ImageView();
	private ImageView toggleTextButton = new ImageView();
	private BufferedWriter saveWriter;
	private BufferedReader saveReader;
	private File savePath;

	public Menu(Image save, Image saveHover, Image load, Image loadHover, Image quit, Image quitHover, Image toggleText,
			Image toggleTextHover) {
		//Creates the path to save the progress to.
		String path = new File("").getAbsolutePath() + "\\data\\saves\\save.txt";
		savePath = new File(path);
		//Arranges the buttons to the desired locations on screen.
		saveButton.setImage(save);
		loadButton.setImage(load);
		quitButton.setImage(quit);
		toggleTextButton.setImage(toggleText);
		saveButton.setFitWidth(200);
		loadButton.setFitWidth(200);
		toggleTextButton.setFitWidth(200);
		quitButton.setFitWidth(200);
		saveButton.setFitHeight(Panel.panelHeight / 4);
		loadButton.setFitHeight(Panel.panelHeight / 4);
		toggleTextButton.setFitHeight(Panel.panelHeight / 4);
		quitButton.setFitHeight(Panel.panelHeight / 4);
		loadButton.setLayoutX(Panel.panelWidth - loadButton.getFitWidth());
		loadButton.setLayoutY(0 * Panel.panelHeight / 4);
		saveButton.setLayoutX(Panel.panelWidth - saveButton.getFitWidth());
		saveButton.setLayoutY(Panel.panelHeight / 4);
		toggleTextButton.setLayoutX(Panel.panelWidth - toggleTextButton.getFitWidth());
		toggleTextButton.setLayoutY(2 * Panel.panelHeight / 4);
		quitButton.setLayoutX(Panel.panelWidth - quitButton.getFitWidth());
		quitButton.setLayoutY(3 * Panel.panelHeight / 4);
		//These just have the buttons give visual feedback upon hovering them.
		saveButton.setOnMouseEntered(event -> {
			saveButton.setImage(saveHover);
		});
		saveButton.setOnMouseExited(event -> {
			saveButton.setImage(save);
		});
		quitButton.setOnMouseEntered(event -> {
			quitButton.setImage(quitHover);
		});
		quitButton.setOnMouseExited(event -> {
			quitButton.setImage(quit);
		});
		loadButton.setOnMouseEntered(event -> {
			loadButton.setImage(loadHover);
		});
		loadButton.setOnMouseExited(event -> {
			loadButton.setImage(load);
		});
		toggleTextButton.setOnMouseEntered(event -> {
			toggleTextButton.setImage(toggleTextHover);
		});
		toggleTextButton.setOnMouseExited(event -> {
			toggleTextButton.setImage(toggleText);
		});
		//Closes the program
		quitButton.setOnMouseClicked(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				System.exit(0);
			}
		});
		//Sets draw text to on or off, in case the player does not want to read the text and only wants to admire the artwork. Only included because I needed another option to round out the space in the GUI, and many popular VNs have this option.
		toggleTextButton.setOnMouseClicked(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				if (Client.drawText) {
					Client.drawText = false;
				} else {
					Client.drawText = true;
				}
			}
		});
		// Creates a new writer, writes the current panel number to a file, then closes
		// the writer. A new writer has to be created each time because it has to be
		// closed in order to successfully write to a file.
		saveButton.setOnMouseClicked(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				try {
					saveWriter = new BufferedWriter(new FileWriter(savePath));
				} catch (IOException e) {
					e.printStackTrace();
				}
				saveGame();
				try {
					saveWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		// Creates a reader, reads in the number from the save file, and sets the panel number to it. The next time an input is given, the game will jump to that panel.
		loadButton.setOnMouseClicked(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				try {
					saveReader = new BufferedReader(new FileReader(savePath));
				} catch (IOException e) {
					e.printStackTrace();
				}
				loadGame();
				try {
					saveReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void saveGame() {
		try {
			saveWriter.write(Integer.toString(Client.getPanelNum()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void loadGame() {
		try {
			Client.setPanelNum(Integer.parseInt(saveReader.readLine()) - 1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Called once, adds the buttons to the group, but does not set them to be visible.
	public void initMenu(Group group) {
		group.getChildren().add(saveButton);
		group.getChildren().add(loadButton);
		group.getChildren().add(toggleTextButton);
		group.getChildren().add(quitButton);
		saveButton.setVisible(false);
		loadButton.setVisible(false);
		toggleTextButton.setVisible(false);
		quitButton.setVisible(false);
	}

	//Sets the buttons to be visible.
	public void openMenu(Group group) {
		saveButton.setVisible(true);
		loadButton.setVisible(true);
		toggleTextButton.setVisible(true);
		quitButton.setVisible(true);
	}

	//Sets the buttons to be invisible.
	public void closeMenu(Group group) {
		saveButton.setVisible(false);
		loadButton.setVisible(false);
		toggleTextButton.setVisible(false);
		quitButton.setVisible(false);
	}
}
