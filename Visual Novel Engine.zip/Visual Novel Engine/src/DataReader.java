import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DataReader {
	private BufferedReader reader;
	public static int lineNumber = 1;
	/**
	 * Reads strings from a file
	 * @param fileName the name of the file from which it will read information
	 */
	public DataReader(String fileName) {
		try {
			String currentDir = new File("").getAbsolutePath() + "\\data\\novel\\";
		    this.reader = new BufferedReader(new FileReader(currentDir + fileName + ".txt"));
		} catch (FileNotFoundException e) {
			System.out.println("You have no file");
			e.printStackTrace();
		}
	}
	
	public String read() {
		try {
			String input = reader.readLine();
			if(input == null) {
				return null;
			}
			//Increments the line number every time a line is read, which is used for saving progress and debugging.
			lineNumber++;
			return interpret(input).trim();
		} 
		catch (IOException e) {
			//Just for debugging
			System.out.println("Error reading line");
			e.printStackTrace();
			return null;
		}
	}
	
	public void close() throws IOException {
		reader.close();
	}
	/**
	 * Determines whether the syntax of the file is correct, then returns the line if it is correct syntax.
	 * @param line	The line to check for correctness.
	 * @return	Either the unmodified line, or an error message that breaks the program, which it should because the syntax is incorrect.
	 */
	public String interpret(String line) {
		//Does not specially interpret the data until after line 3, as the first 3 lines should always be title, authors, date in that order.
		if(line.charAt(0) != '#' || lineNumber <= Client.charNum + 3) {
			return line;
		}
		else {
			//Returns the line unless it is none of the following options.
			switch(line) {
			case "#Next":
			case "#End":
			case "#Default":
			case "#Animate":
			case "#Interact":
			case "#None":
			case "#BlackTransition":
				return line;
			default: 
				System.out.println("Formatting error on line " + lineNumber);
				System.out.println("error ->" + line);
				return "ERROR: IMPROPERLY FORMAT ON LINE " + lineNumber + " FIX YOUR FORMATTING";
			}
		}
	}
}
