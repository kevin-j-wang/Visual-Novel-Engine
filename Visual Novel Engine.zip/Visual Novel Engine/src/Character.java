import java.io.File;
import java.util.HashMap;

import javafx.scene.image.Image;

public class Character {
	private String name;
	//HashMap that stores all variant images of the same character.
	private HashMap<String, Image> sprites = new HashMap<>();
	public Character(String characterName) {
		name = characterName;
		String path = new File("").getAbsolutePath() + "\\data\\assets\\characters\\";
		File directory = new File(path);
		//Get all the files in the folder named character and if it matches the name of the Character string passed to the constructor then add it to the HashMap.
		for(final File fileEntry : directory.listFiles()) {
			//Only accepts it if the name matches and the file extension is png
			if(fileEntry.getName().substring(0, name.length()).equals(name) && fileEntry.getName().substring(fileEntry.getName().length() - 4, fileEntry.getName().length()).equals(".png")) {
				sprites.put(fileEntry.getName().substring(name.length() + 1, fileEntry.getName().length() - 4), new Image("file:" + path + fileEntry.getName()));
			}
		}
	}
	/**
	 * 
	 * @param type The key value of the Image to get.
	 * @return An image from the HashMap with the key value of the parameter.
	 */
	public Image get(String type) {
		return sprites.get(type);
	}
	
	public String getName() {
		return name;
	}
}
