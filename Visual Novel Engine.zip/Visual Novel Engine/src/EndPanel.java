import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.util.Duration;

public class EndPanel extends Panel {
	/**
	 * Sets the background and character images of the panel.
	 * @param backgroundImage An image containing the background of the panel. 
	 * @param characterImage An image containing a character that will be drawn on top of the panel.
	 */
	public EndPanel(Image backgroundImage, Image characterImage) {
		super(backgroundImage, characterImage);
	}

	@Override
	public void draw(GraphicsContext gc) {
		Timeline timeline = new Timeline();
		//The keyframe doesn't have anything in it because every action is within the handle method within the FrameProcessor class.
		KeyFrame frame = new KeyFrame(Duration.seconds(0.032), new FrameProcessor(gc, timeline){});
		timeline.getKeyFrames().add(frame);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}
	//The ending panel always displays "The End", both methods do the same thing.
	@Override
	public void drawNoText(GraphicsContext gc) {
		draw(gc);
	}

}
