import java.util.ArrayList;
import java.util.List;

import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class FrameProcessor implements EventHandler<ActionEvent> {
	//All ActionEvents and GraphicsContexts are the same thing that are passed as a necessity.
	
	private GraphicsContext gc;
	private Timeline timeline;
	private Image background;
	private Image character;
	// The kind of effect that will be applied during transition.
	private String preEffect;
	private String postEffect;
	private List<String> splitText = new ArrayList<>();
	// Stores the different lines that the original line will be split into.
	private int index = 1;
	// The location of the current character that the program is at while it
	// scrolls across the line.
	private int lines = 0;

	private int frameCount1 = 0;
	private int frameCount2 = 0;

	private boolean drawText = true;
	private boolean frameFinished = false;
	private boolean postFinished = false;
	private boolean isEnd = false;

	public static Color blackFade = new Color(0, 0, 0, 0.1);
	public static Color whiteFade = new Color(1, 1, 1, 0.1);

	public FrameProcessor(GraphicsContext gc, String text, Image background, Image character, String preEffect,
			String postEffect, double textBoxWidth, Timeline timeline) {
		this.gc = gc;
		this.timeline = timeline;
		this.background = background;
		this.character = character;
		this.preEffect = preEffect;
		this.postEffect = postEffect;
		// Adds an empty line to which characters will be added to incrementally
		splitText.add("");
		for (int i = 0; i < text.length(); i++) {
			String current = splitText.get(splitText.size() - 1);
			String newLine = current + text.charAt(i);
			if (measure(newLine) > textBoxWidth) {
				// Only stops adding characters at whole words, so it words will
				// not be cut off in the middle.
				int index = current.lastIndexOf(' ');
				splitText.add(current.substring(index + 1) + text.charAt(i));
				splitText.set(splitText.size() - 2, current.substring(0, index));
			} else {
				splitText.set(splitText.size() - 1, newLine);
			}

		}
	}

	public FrameProcessor(GraphicsContext gc, boolean drawText, Image background, Image character, String preEffect,
			String postEffect, Timeline timeline) {
		this.gc = gc;
		this.timeline = timeline;
		this.background = background;
		this.character = character;
		this.drawText = drawText;
		this.preEffect = preEffect;
		this.postEffect = postEffect;
	}

	public FrameProcessor(GraphicsContext gc, Timeline timeline) {
		this.preEffect = "#BlackTransition";
		this.postEffect = "#BlackTransition";
		this.gc = gc;
		this.timeline = timeline;
		this.isEnd = true;
	}

	@Override
	public void handle(ActionEvent e) {
		//If there are preanimations or post animation, render them, then draw out the panel as usual. Otherwise, draw out the panel as usual.
		if(isEnd) {
			endHandle(e);
		}
		else if (!preEffect.equals("#None") && !preEffect.equals("#Default")) {
			preHandle(e);
			//if it is the end, handle it specially.
		}
		else {
			defaultHandle(e);
		}
		if (frameFinished && !postEffect.equals("#None") && !postEffect.equals("#Default")) {
			postHandle(e);
		}
		else if(frameFinished) {
			timeline.stop();
		}
	}
	
	private void endHandle(ActionEvent e) {
		Text theEnd = new Text("THE END");
		gc.setFill(Color.BLACK);
		gc.fillRect(0, 0, Panel.panelWidth, Panel.panelHeight);
		gc.setFill(Color.WHITE);
		gc.fillText(theEnd.getText(), Panel.panelWidth/2 - theEnd.getLayoutBounds().getWidth(), Panel.panelHeight/2);
		Client.endGame = true;
	}

	private void preHandle(ActionEvent e) {
		if(preEffect.equals("#BlackTransition")) {
			blackFadeHandle1(e);
			if (frameCount1 >= 30) {
				defaultHandle(e);
			}
		}
	}
	
	private void postHandle(ActionEvent e) {
		if(postEffect.equals("#BlackTransition")) {
			blackFadeHandle2(e);
			if(postFinished) {
				timeline.stop();
			}
		}
	}

	// Every transition is broken up into 2 parts, one at the beginning of the
	// panel and one at the end. The one at the end is suffixed '1', and the one
	// at the beginning is suffixed '2'.

	//Each frame, redraw the entire frame but with slightly less black layered on it, so it goes from opaque to fully visible smoothly. 
	private void blackFadeHandle1(ActionEvent e) {
		Client.inProgress = true;
		gc.setFill(blackFade);
		frameCount1++;
		if (frameCount1 < 30) {
			gc.drawImage(background, 0, 0, Panel.panelWidth, Panel.panelHeight);
			gc.drawImage(character, Panel.panelWidth / 2 - character.getWidth() / 2,
					Panel.panelHeight - character.getHeight());
			for (int i = 30 - frameCount1; i > 0; i--) {
				gc.fillRect(0, 0, Panel.panelWidth, Panel.panelHeight);
			}
		} else {
			Client.inProgress = false;
			Client.visible = true;
		}
	}

	//Does the opposite of the previous method.
	private void blackFadeHandle2(ActionEvent e) {
		Client.inProgress = true;
		gc.setFill(blackFade);
		frameCount2++;
		if (frameCount2 < 30) {
			for (int i = 0; i < frameCount2; i++) {
				gc.fillRect(0, 0, Panel.panelWidth, Panel.panelHeight);
			}
		} else {
			gc.setFill(Color.BLACK);
			gc.fillRect(0, 0, Panel.panelWidth, Panel.panelHeight);
			postFinished = true;
			Client.inProgress = false;
			Client.visible = false;
		}
	}
	
	//Writes out the text like a printer, character by character. Stops upon writing all characters in a frame.
	//Also draws other stuff, like the background image, character, and slightly transparent text box where the text is contained in.
	private void defaultHandle(ActionEvent e) {
		Client.inProgress = true;
		double y = Panel.panelHeight / 2;
		gc.drawImage(background, 0, 0, Panel.panelWidth, Panel.panelHeight);
		gc.setFill(Panel.textBoxColor);
		gc.drawImage(character, Panel.panelWidth / 2 - character.getWidth() / 2,
				Panel.panelHeight - character.getHeight());
		if (drawText) {
			gc.fillRect(Panel.bezelSize, Panel.panelHeight / 2, Panel.panelWidth - Panel.bezelSize * 2,
					Panel.panelHeight / 2 - 10);
			gc.setFill(Color.WHITE);
			for (int i = 0; i < lines; i++) {
				gc.fillText(splitText.get(i), Panel.bezelSize + 10, y += Client.font.getSize());
			}
		}
		if (lines < splitText.size()) {
			gc.fillText(splitText.get(lines).substring(0, index++), Panel.bezelSize + 10, y + 40);
			if (index == splitText.get(lines).length() + 1) {
				lines++;
				index = 0;
			}
		} else {
			frameFinished = true;
			Client.inProgress = false;
		}
	}

	// Measures the length of the string in pixels not characters
	private int measure(String text) {
		Text t = new Text(text);
		t.setFont(Client.font);
		return (int) t.getLayoutBounds().getWidth();
	}

}
